package Source;

import Source.Interface.Principal;

public class Main {
    public static void main(String[] args) {
        @SuppressWarnings("unused")
        Principal Tpr = new Principal();  
    }
}